package Entidades;

public class DirectorInfo {
    private Persona nombre;
    private int cantidadPeliculas;
    private double mediaCalificaciones;


}
