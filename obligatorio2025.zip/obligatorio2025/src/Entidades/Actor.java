package Entidades;

public class Actor extends Persona {
    protected Actor(String nombre, int dni) {
        super(nombre, dni);
    }
}
