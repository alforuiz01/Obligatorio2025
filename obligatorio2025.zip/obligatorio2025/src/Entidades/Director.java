package Entidades;

public class Director extends Persona {

    protected Director(String nombre, int dni) {
        super(nombre, dni);
    }
}
