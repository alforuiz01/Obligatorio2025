package Entidades;

public class ActorInfo {
    private int mes;
    private Persona nombreActor;
    private int cantidadPeliculas;
    private int calificaciones;

    // Constructor, getters y setters
}