package uy.edu.um.tad.stack;

public class EmptyStackException extends Exception {
}
