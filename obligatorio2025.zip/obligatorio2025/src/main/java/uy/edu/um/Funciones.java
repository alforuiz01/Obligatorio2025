package uy.edu.um;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Funciones {

        public static void cargarDatos() {
            long inicio = System.currentTimeMillis();

            try {
                cargarPeliculas("movies_metadata.csv");
                cargarRatings("ratings.csv");
                cargarCreditos("credits.csv");
            } catch (IOException e) {
                System.out.println("Error al cargar los archivos: " + e.getMessage());
                return;
            }

            long fin = System.currentTimeMillis();
            System.out.println("Carga de datos exitosa, tiempo de ejecución de la carga: " + (fin - inicio) + " ms");
        }

        private static void cargarPeliculas(String path) throws IOException {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String linea = br.readLine();
            while ((linea = br.readLine()) != null) {
            }
            br.close();
        }

        private static void cargarRatings(String path) throws IOException {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String linea = br.readLine();
            while ((linea = br.readLine()) != null) {
            }
            br.close();
        }

        private static void cargarCreditos(String path) throws IOException {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String linea = br.readLine();
            while ((linea = br.readLine()) != null) {
            }
            br.close();
        }
    }