package uy.edu.um.tad.queue;

public class EmptyQueueException extends Exception {

}
